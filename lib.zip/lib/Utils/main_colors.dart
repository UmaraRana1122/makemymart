import 'package:flutter/material.dart';

class MainColor {
  static const colorPurple = Color(0xff8A33FD);
  static const colorBlack = Color(0xFF191C1F);
  static const colorWhite = Color(0xFFFFFFFF);
  static const colorGrey = Color(0xff999999);

  static const colorLightWhite = Color(0xffF2F2F2);

  static const colorGreyLight = Color(0xffCCCCCC);
  static const lightBlack = Color(0xFF2b2b2b);
  static const colorBlack1 = Color(0xFF3c4242);
  static const colorNaturalBlack = Color(0xFF333333);
  static const colorNaturalWhite = Color(0xFFdcdcdc);
}
