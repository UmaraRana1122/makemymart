import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:makemymart/Utils/main_colors.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

Widget textWidget(
  String text, {
  fontSize,
  FontWeight? fontWeight,
  Color? color,
  TextAlign? textAlign,
}) {
  return Padding(
    padding: const EdgeInsets.all(4.0),
    child: Text(
      text,
      textAlign: textAlign ?? TextAlign.start,
      style: GoogleFonts.poppins(
        color: color ?? MainColor.colorBlack,
        fontSize: fontSize ?? 20.sp,
        fontWeight: fontWeight ?? FontWeight.w500,
      ),
    ),
  );
}
